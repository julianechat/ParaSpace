*******************************************************************************
http://www.geogratis.ca/
Created : 2007/04/01
*******************************************************************************

[NOTICE]
Only the English XML metadata file is valid according to the XML (W3C) schema as
defined by the Federal Geographic Data Committee (FGDC) (http://www.fgdc.gov).
The French version of the XML metadata file does not respect the domain of values,
which is only available in English in certain fields, and exists solely for the
presentation of information.

Users must ensure that they use the FGDC XML schema with the English version of
the XML metadata to validate the metadata.


[CONTENT OF THE ZIPPED FILE]
This zipped file contains the following files:

- Two metadata files (English and French versions) with .xml extension used to
  display the metadata of the data set. A style sheet in .xsl file format is
  available for both languages from the GeoGratis (http://www.geogratis.ca/fgdc/)
  site. The above notice applies to these files.

- Two metadata files (English and French versions) with .html extension used to
  display the metadata of the data set. The style sheets have already been applied
  to these files.

- One or more data files.
